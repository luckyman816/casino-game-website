-- MySQL dump 10.13  Distrib 8.0.39, for Linux (x86_64)
--
-- Host: localhost    Database: softofgames
-- ------------------------------------------------------
-- Server version	8.0.39-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `w_shops`
--

DROP TABLE IF EXISTS `w_shops`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `w_shops` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `balance` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `frontend` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `currency` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `percent` int NOT NULL DEFAULT '90',
  `max_win` int NOT NULL DEFAULT '100',
  `shop_limit` int NOT NULL DEFAULT '200',
  `is_blocked` int NOT NULL DEFAULT '0',
  `access` int DEFAULT '0',
  `country` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `os` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `device` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `orderby` enum('AZ','Rand','RTP','Count','Date') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'AZ',
  `user_id` int NOT NULL,
  `pending` int NOT NULL DEFAULT '0',
  `rules_terms_and_conditions` int NOT NULL DEFAULT '0',
  `rules_privacy_policy` int NOT NULL DEFAULT '0',
  `rules_general_bonus_policy` int NOT NULL DEFAULT '0',
  `rules_why_bitcoin` int NOT NULL DEFAULT '0',
  `rules_responsible_gaming` int NOT NULL DEFAULT '0',
  `happyhours_active` int NOT NULL DEFAULT '1',
  `progress_active` int NOT NULL DEFAULT '1',
  `invite_active` int NOT NULL DEFAULT '1',
  `welcome_bonuses_active` int NOT NULL DEFAULT '1',
  `sms_bonuses_active` int NOT NULL DEFAULT '1',
  `wheelfortune_active` int DEFAULT '1',
  `whatupno` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`(191))
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `w_shops`
--

LOCK TABLES `w_shops` WRITE;
/*!40000 ALTER TABLE `w_shops` DISABLE KEYS */;
INSERT INTO `w_shops` VALUES (1,'shop',10099666.3514,'Default','EUR',90,50,100,0,0,NULL,NULL,NULL,'RTP',3,0,0,0,0,0,0,1,0,1,1,1,1,NULL),(13,'MainShop',999667.0000,'Default','USD',90,100,200,0,0,NULL,NULL,NULL,'RTP',569,0,0,0,0,0,0,1,1,1,1,1,1,NULL),(12,'TotalbetShop',109667.0000,'Default','USD',90,100,200,0,0,NULL,NULL,NULL,'RTP',556,0,0,0,0,0,0,1,1,1,1,1,1,NULL),(14,'ApiShop',100000.0000,'Default','USD',90,100,200,0,0,NULL,NULL,NULL,'RTP',579,0,0,0,0,0,0,1,1,1,1,1,1,NULL),(15,'AllShop',100000.0000,'Default','USD',90,100,200,0,0,NULL,NULL,NULL,'RTP',586,0,0,0,0,0,0,1,1,1,1,1,1,NULL),(16,'NewShop1',99445.0000,'Default','USD',90,100,200,0,0,NULL,NULL,NULL,'RTP',613,0,0,0,0,0,0,1,1,1,1,1,1,NULL),(17,'ShopA',100000.0000,'Default','USD',90,100,200,0,0,NULL,NULL,NULL,'RTP',618,0,0,0,0,0,0,1,1,1,1,1,1,NULL),(20,'FixedShop',99667.0000,'Default','USD',90,100,200,0,0,NULL,NULL,NULL,'RTP',680,0,0,0,0,0,0,1,1,1,1,1,1,NULL);
/*!40000 ALTER TABLE `w_shops` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-28 20:29:27
